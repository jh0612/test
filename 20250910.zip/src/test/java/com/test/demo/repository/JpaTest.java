/**
 * 
 */
package com.test.demo.repository;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.test.demo.entity.User;

import lombok.extern.slf4j.Slf4j;

/**
 * @author 70998115
 *
 */
@Slf4j
@SpringBootTest
public class JpaTest {
	

    @Autowired
    private UserRepository userRepository;

    @Test
    public void test() throws Exception {
        // 创建10条记录
        userRepository.save(new User("AAA", "123", "18210011111"));
        userRepository.save(new User("BBB", "456", "18210022222"));
        userRepository.save(new User("CCC", "asd", "18210033333"));
        userRepository.save(new User("DDD", "zxc", "18210044444"));
        userRepository.save(new User("EEE", "qwe", "18210055555"));
        
        User findByUsername = userRepository.findByUsername("DDD");
        System.out.println(findByUsername);
        // 测试findAll, 查询所有记录
        Assertions.assertEquals(5, userRepository.findAll().size());

        // 测试findByName, 查询姓名为DDD的User
        Assertions.assertEquals("18210044444", userRepository.findByUsername("DDD").getPhone());

        // 测试findUser, 查询姓名为CCC的User
        Assertions.assertEquals("18210033333", userRepository.findUser("CCC").getPhone());

        // 测试findByNameAndAge, 查询姓名为AAA并且手机号为18210011111的User
        Assertions.assertEquals("AAA", userRepository.findByUsernameAndPhone("AAA", "18210011111").getUsername());

        // 测试删除姓名为AAA的User
        userRepository.delete(userRepository.findByUsername("AAA"));

        // 测试findAll, 查询所有记录, 验证上面的删除是否成功
        Assertions.assertEquals(4, userRepository.findAll().size());

    }	

}
