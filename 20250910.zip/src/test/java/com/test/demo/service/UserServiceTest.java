package com.test.demo.service;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.test.demo.entity.User;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
public class UserServiceTest {

	@Autowired
	UserService userService;

	@Test
	public void findByIdCreateByUsernameTest() {
		userService.findByIdCreateByUsername();
	}

	@Test
	public void streamTest() {
//		long streamStu = userService.streamStu();
//		System.out.println(streamStu);
		List<User> streamStu = userService.streamStu();
		streamStu.forEach(System.out::println);
		System.out.println("********************StreamTest********************");
	}

}
