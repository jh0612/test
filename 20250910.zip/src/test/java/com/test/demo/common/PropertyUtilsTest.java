/**
 * 
 */
package com.test.demo.common;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.test.demo.dto.UserDto;
import com.test.demo.entity.User;
import com.test.demo.repository.UserRepository;

import lombok.extern.slf4j.Slf4j;

/**
 * @author 70998115
 *
 */
@SpringBootTest
@Slf4j
public class PropertyUtilsTest {

	@Autowired
	UserRepository userRepository;

	@Test
	public void test1() {
		// 创建源对象并赋值
		Optional<User> userOptional = userRepository.findById(1L);

		log.info("User: {} {} {}", userOptional.get(), userOptional.get().getCreateBy(),
				userOptional.get().getCreateTime());

		// 创建目标对象
		UserDto dto = new UserDto();

		// 复制属性（会复制名称和类型都相同的属性,并且指定属性的属性不会复制）
//	    PropertyUtils.copyProperties(user, dto,"id","liked");
		BeanUtils.copyProperties(userOptional.get(), dto);
		log.info("UserDto: {}", dto);
		// 此时dto的name和age会被赋值为user的对应值
		System.out.println(dto.getUsername()); // 输出：Diana
		System.out.println(dto.getPhone()); // 输出：18211110000
	}

}
