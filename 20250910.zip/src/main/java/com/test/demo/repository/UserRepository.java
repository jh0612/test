/**
 * 
 */
package com.test.demo.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.test.demo.entity.User;

/**
 * @author 70998115 所有实体类的Repository均继承于BaseRepository泛型为实体类和该实体主键的数据类型
 */
@Repository
public interface UserRepository extends BaseRepository<User, Long> {

	User findByUsername(String username);

	User findByUsernameAndPhone(String username, String phone);

	@Query("from User u where u.username=:username")
	User findUser(@Param("username") String username);

}
