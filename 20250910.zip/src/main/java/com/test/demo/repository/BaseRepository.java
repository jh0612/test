/**
 * 
 */
package com.test.demo.repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.NoRepositoryBean;

import com.test.demo.entity.BaseEntity;

/**
 * @author 70998115
 * 基础Repository，所有自定义的Repository都要继承于它。
 * <T, I> T:谁的Repository就是谁。 I：主键的数据类型，目前都是主键自增所以是Long，用UUID或者雪花算法就是String
 * 参考网站：
 * https://pdai.tech/md/spring/springboot/springboot-x-postgre-jpa.html#jpa%E7%9B%B8%E5%85%B3
 */
@NoRepositoryBean
public interface BaseRepository <T extends BaseEntity, I extends Serializable> extends JpaRepository<T, I>, JpaSpecificationExecutor<T> {
}
