/**
 * 
 */
package com.test.demo.exception;

/**
 * @author 70998115
 *
 */

public class EntityNotFoundException extends RuntimeException {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EntityNotFoundException(String message) {
        super(message);
    }
}
