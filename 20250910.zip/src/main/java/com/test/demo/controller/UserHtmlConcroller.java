/**
 * 
 */
package com.test.demo.controller;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.test.demo.entity.User;
import com.test.demo.service.UserService;

import lombok.extern.slf4j.Slf4j;

/**
 * @author 70998115
 * HTML用コントローラ
 */
@Controller
@Slf4j
public class UserHtmlConcroller {

	@Autowired
	private UserService userService;
	
//	public UserHtmlConcroller(UserService userService) {
//		this.userService = userService;
//	}
	
	@GetMapping("/selectuser")
	public ModelAndView getEmps(ModelAndView mav){
		System.out.println(userService.findAll());
	    Collection<User> user = userService.findAll();
	    //放入域中
	    mav.addObject("entityhtml",user);
	    mav.setViewName("index");
	    return mav;
	}
	
    //删除员工
    @RequestMapping (value = "/delete/{id}",method = RequestMethod.POST)
    public String deleteUser(@PathVariable("id") Long id) {
        //根据id删除员工
        userService.delete(id);
        //删除后返回本页面 主页
        return "redirect:/selectuser";
    }
	
   //回显页面
   @RequestMapping (value = "/editUser/{id}")
   public ModelAndView selectUp(@PathVariable("id") Long id,ModelAndView mav) {
       User user = userService.find(id);
       System.out.println("进来了update"+user);
       mav.addObject("user",user);
       mav.setViewName("crud/edit");
       return mav;
   }
    
	@PostMapping("/updatehtml")
	@ResponseBody
	public Map<String, Object> editUser(@RequestBody User user) {
		Map<String, Object> result = new HashMap<>();
		try {
//			userService.updateById(user.getId(), user.getAge(), user.getName());
			System.out.println("更新了："+user);
			result.put("resultCode", 200);
	        result.put("message", "修改成功");
		}catch(Exception e) {
			e.printStackTrace();
	        result.put("resultCode", 500);
	        result.put("message", "修改失败：" + e.getMessage());
		}
		return result;
    }

	
	@RequestMapping (value = "/add")
	   public ModelAndView add(ModelAndView mav) {
	       mav.setViewName("crud/addUser");
	       return mav;
	   }
	
    @RequestMapping("/adduser")
	@ResponseBody
	public Map<String, Object> addUser(@RequestBody User user) {
    	Map<String, Object> result = new HashMap<>();

//    	log.info("希望新规的用户情报 : {} {} {}",user.getId(),user.getAge(),user.getName());
    	try {
    		if(userService.find(user.getId()) != null) {
        		result.put("resultCode", 510);
    	        result.put("message", "ID重复，新规失败 ⇒");
    	        result.put("userid", user.getId());
    	        return result;
    		}
			userService.save(user);
			System.out.println("新规了："+user);
			result.put("resultCode", 200);
	        result.put("message", "新增成功");
    	}catch(Exception e) {
			e.printStackTrace();
	        result.put("resultCode", 500);
	        result.put("message", "新增失败：" + e.getMessage());
		}
		return result;
	}
	
	
}
