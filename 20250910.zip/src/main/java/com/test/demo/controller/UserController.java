package com.test.demo.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.test.demo.entity.User;
import com.test.demo.entity.query.UserQueryBean;
import com.test.demo.entity.response.ResponseResult;
import com.test.demo.service.UserService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * @author 70998115
 *
 */
@Tag(name = "User类登录用Controller", description = "Operations related to user management") // swagger用注解
@RestController
@RequestMapping("/api/user")
@CrossOrigin(origins = "http://localhost:8089") // 跨域资源共享（CORS）策略 允许前端域名 本地调试用
//@CrossOrigin(origins = "http://10.97.24.24:8080") //打包用
public class UserController extends BaseController {

	private final UserService userService;

	public UserController(UserService userService) {
		this.userService = userService;
	}

	/**
	 * 成功返回结果，参考这个按需熟悉使用其他
	 * 
	 * @return ResponseEntity<ApiResponse>
	 */
	@Operation(summary = "获取所有用户", description = "User表中必须存在数据") // 对每一个方法进行摘要（summary）和描述细节（description）
	@GetMapping
	public ResponseEntity<ApiResponse> getUsers() {
		// 记录详细请求日志()Basecontroller中注解標注的方法最先執行，其中封裝了log相關功能
		// logRequest();
		List<User> users = userService.findAll();
		return success(users);
	}

	/**
	 * 测试使用，实际需要删除
	 * 
	 * @return ResponseEntity<ApiResponse>
	 */
	@GetMapping("byid")
	public ResponseEntity<ApiResponse> getUser() {
		User user = userService.find(2L);
		return success(user);
	}

	@PostMapping
	public ResponseEntity<ApiResponse> createUser(@Valid @RequestBody User user, BindingResult bindingResult) {
		if (bindingResult.hasErrors()) {
			return handleValidationError(bindingResult);
		}
		User saveEntity = userService.saveEntity(user);
		return success(saveEntity);
	}

	/**
	 * @param user user param
	 * @return user
	 */
	@Operation(summary = "新增或者编辑用户", description = "如果id存在自动变为编辑该id的用户")
	@PostMapping("add")
	public ResponseResult<User> add(User user) {
		if (user.getId() == null || !userService.exists(user.getId())) {
			userService.save(user);
		} else {
			userService.update(user);
		}
		return ResponseResult.success(userService.find(user.getId()));
	}

	/**
	 * @return user list
	 */
	@Operation(summary = "根据id编辑用户信息", description = "根据前端传过来的id用GET方式进行编辑用户信息")
	@GetMapping("edit/{userId}")
	public ResponseResult<User> edit(@PathVariable("userId") Long userId) {
		return ResponseResult.success(userService.find(userId));
	}

	/**
	 * @return user list
	 */
	@Operation(summary = "带分页形式的获取user的list", description = "第一个参数是一页内承载的数据条数，第二个参数是当前是第几页")
	@GetMapping("list")
	public ResponseResult<Page<User>> list(@RequestParam int pageSize, @RequestParam int pageNumber) {
		return ResponseResult
				.success(userService.findPage(UserQueryBean.builder().build(), PageRequest.of(pageNumber, pageSize)));
	}

}
