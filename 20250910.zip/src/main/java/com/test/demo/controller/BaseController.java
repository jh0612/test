package com.test.demo.controller;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

/**
 * 基础控制器，提供通用功能 所有控制器都可以继承此类以获得通用方法
 */
public abstract class BaseController {

	// 日志对象，使用子类的类名作为日志名称
	protected final Logger logger = LoggerFactory.getLogger(getClass());

	/**
	 * 获取当前请求对象
	 * 
	 * @return HttpServletRequest
	 */
	protected HttpServletRequest getRequest() {
		ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
		if (attributes == null) {
			logger.warn("无法获取当前请求对象");
			return null;
		}
		return attributes.getRequest();
	}

	/**
	 * 获取当前响应对象
	 * 
	 * @return HttpServletResponse
	 */
	protected HttpServletResponse getResponse() {
		ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
		if (attributes == null) {
			logger.warn("无法获取当前响应对象");
			return null;
		}
		return attributes.getResponse();
	}

	/**
	 * 获取当前会话对象
	 * 
	 * @return HttpSession
	 */
	protected HttpSession getSession() {
		HttpServletRequest request = getRequest();
		return request != null ? request.getSession() : null;
	}

	/**
	 * 获取请求头信息
	 * 
	 * @return 所有请求头的键值对
	 */
	protected Map<String, String> getRequestHeaders() {
		HttpServletRequest request = getRequest();
		if (request == null) {
			return new HashMap<>();
		}

		Map<String, String> headers = new HashMap<>();
		Enumeration<String> headerNames = request.getHeaderNames();
		while (headerNames.hasMoreElements()) {
			String name = headerNames.nextElement();
			headers.put(name, request.getHeader(name));
		}
		return headers;
	}

	/**
	 * 获取指定名称的请求头
	 * 
	 * @param headerName 头名称
	 * @return 头值
	 */
	protected String getRequestHeader(String headerName) {
		HttpServletRequest request = getRequest();
		return request != null ? request.getHeader(headerName) : null;
	}

	/**
	 * 获取所有请求参数
	 * 
	 * @return 所有请求参数的键值对
	 */
	protected Map<String, String[]> getRequestParameters() {
		HttpServletRequest request = getRequest();
		return request != null ? request.getParameterMap() : new HashMap<>();
	}

	/**
	 * 获取指定名称的请求参数
	 * 
	 * @param paramName 参数名称
	 * @return 参数值
	 */
	protected String getRequestParam(String paramName) {
		HttpServletRequest request = getRequest();
		return request != null ? request.getParameter(paramName) : null;
	}

	/**
	 * 获取客户端IP地址（考虑代理情况）
	 * 
	 * @return 客户端真实IP
	 */
	protected String getClientIp() {
		HttpServletRequest request = getRequest();
		if (request == null) {
			return "未知IP";
		}

		String ip = request.getHeader("x-forwarded-for");
		if (isValidIp(ip)) {
			// 处理多级代理，取第一个有效IP
			if (ip.contains(",")) {
				ip = ip.split(",")[0].trim();
			}
			return ip;
		}

		ip = request.getHeader("Proxy-Client-IP");
		if (isValidIp(ip)) {
			return ip;
		}

		ip = request.getHeader("WL-Proxy-Client-IP");
		if (isValidIp(ip)) {
			return ip;
		}

		ip = request.getHeader("HTTP_CLIENT_IP");
		if (isValidIp(ip)) {
			return ip;
		}

		ip = request.getHeader("HTTP_X_FORWARDED_FOR");
		if (isValidIp(ip)) {
			return ip;
		}

		return request.getRemoteAddr();
	}

	/**
	 * 检查IP是否有效
	 */
	private boolean isValidIp(String ip) {
		return ip != null && ip.length() > 0 && !"unknown".equalsIgnoreCase(ip);
	}

	/**
	 * 记录"请求"日志
	 */
	protected void logRequest() {
		ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
		if (attributes == null) {
			logger.warn("无法记录请求日志：请求对象为null");
			return;
		}
		if (attributes != null) {
			HttpServletRequest request = attributes.getRequest();
			logger.info("===== 请求详情 =====");
			logger.info("请求URL: {}", request.getRequestURL());
			logger.info("请求方法: {}", request.getMethod());
			logger.info("客户端IP: {}", getClientIp());
			logger.info("请求参数: {}", request.getQueryString());
			logger.info("请求路径: {}", request.getServletPath());
			logger.info("用户代理: {}", request.getHeader("User-Agent"));
			logger.info("===================");
		}
	}

	/**
	 * 记录"响应"日志
	 * 
	 * @param data 响应数据
	 */
	protected void logResponse(Object data) {
		logger.info("===== 响应详情 =====");
		logger.info("响应数据: {}", data != null ? data.toString() : "无数据");
		logger.info("===================");
	}

	/**
	 * 处理成功响应（带日志记录）
	 * 
	 * @param data 响应数据
	 * @return 封装后的成功响应
	 */
	protected ResponseEntity<ApiResponse> success(Object data) {
		ApiResponse response = new ApiResponse(true, "操作成功", data);
		logResponse(data); // 记录响应日志
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	/**
	 * 处理成功响应（无数据，带日志记录）
	 * 
	 * @return 封装后的成功响应
	 */
	protected ResponseEntity<ApiResponse> success() {
		return success(null);
	}

	/**
	 * 处理错误响应（带日志记录）
	 * 
	 * @param message 错误信息
	 * @return 封装后的错误响应
	 */
	protected ResponseEntity<ApiResponse> error(String message) {
		logger.error("错误信息: {}", message); // 记录错误日志
		ApiResponse response = new ApiResponse(false, message, null);
		return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
	}

	/**
	 * 处理错误响应（指定状态码，带日志记录）
	 * 
	 * @param message 错误信息
	 * @param status  状态码
	 * @return 封装后的错误响应
	 */
	protected ResponseEntity<ApiResponse> error(String message, HttpStatus status) {
		logger.error("错误信息: {}, 状态码: {}", message, status.value()); // 记录错误日志
		ApiResponse response = new ApiResponse(false, message, null);
		return new ResponseEntity<>(response, status);
	}

	/**
	 * 处理参数校验错误（带日志记录）
	 * 
	 * @param bindingResult 校验结果
	 * @return 错误响应
	 */
	protected ResponseEntity<ApiResponse> handleValidationError(BindingResult bindingResult) {
		Map<String, String> errors = new HashMap<>();
		for (FieldError error : bindingResult.getFieldErrors()) {
			errors.put(error.getField(), error.getDefaultMessage());
		}
		logger.warn("参数校验失败: {}", errors); // 记录警告日志
		ApiResponse response = new ApiResponse(false, "参数校验失败", errors);
		return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
	}

	/**
	 * 全局异常处理
	 * 
	 * @param e 异常
	 * @return 错误响应
	 */
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ApiResponse> handleException(Exception e) {
		// 记录异常堆栈信息
		logger.error("发生异常: {}", e.getMessage(), e);
		// 实际项目中可以根据不同异常类型返回不同响应
		ApiResponse response = new ApiResponse(false, "服务器内部错误: " + e.getMessage(), null);
		return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	/**
	 * 所有的controller都继承一个基础的controller，在BaseController中
	 * 用@ModelAttribute注解修饰一个方法，就可以做到在执行所有的方法之前，先执行这个方法
	 * 
	 * @param request
	 * @param response
	 */
	@ModelAttribute
	public void common(HttpServletRequest request, HttpServletResponse response) {
		// 记录详细请求日志
		logRequest();

		// 获取请求参数
		String keyword = getRequestParam("keyword");
		logger.info("查询前端请求参数: {}", keyword);

		// 获取请求头信息
		String authToken = getRequestHeader("Authorization");
		logger.info("授权令牌: {}", authToken != null ? "存在" : "不存在");

	}

	/**
	 * API响应封装类
	 */
	protected static class ApiResponse {
		private boolean success;
		private String message;
		private Object data;

		public ApiResponse(boolean success, String message, Object data) {
			this.success = success;
			this.message = message;
			this.data = data;
		}

		// getter和setter
		public boolean isSuccess() {
			return success;
		}

		public void setSuccess(boolean success) {
			this.success = success;
		}

		public String getMessage() {
			return message;
		}

		public void setMessage(String message) {
			this.message = message;
		}

		public Object getData() {
			return data;
		}

		public void setData(Object data) {
			this.data = data;
		}
	}
}
