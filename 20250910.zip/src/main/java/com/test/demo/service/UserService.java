package com.test.demo.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;

import com.test.demo.entity.User;
import com.test.demo.entity.query.UserQueryBean;

public interface UserService extends BaseService<User, Long> {

	/**
	 * find by page.
	 *
	 * @param userQueryBean query
	 * @param pageRequest   pageRequest
	 * @return page
	 */
	Page<User> findPage(UserQueryBean userQueryBean, PageRequest pageRequest);

	// 用Stream流對取得的數據進行流式處理
	public List<User> streamStu();

	/**
	 * 用Specification动态查询 查询条件：1.id>=150; 2.create_by="ADMIN"; 3.username="B%"
	 */
	List<User> findByIdCreateByUsername();

}
