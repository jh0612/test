/**
 * 
 */
package com.test.demo.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.test.demo.entity.User;
import com.test.demo.entity.query.UserQueryBean;
import com.test.demo.repository.BaseRepository;
import com.test.demo.repository.UserRepository;
import com.test.demo.service.UserService;

/**
 * @author 70998115
 *
 */
@Service
@Transactional
public class UserServiceImpl extends BaseServiceImpl<User, Long> implements UserService {

	/**
	 * userRepository.
	 */
	private final UserRepository userRepository;

	/**
	 * init.
	 *
	 * @param repository user repository
	 */
	public UserServiceImpl(final UserRepository repository) {
		this.userRepository = repository;
	}

	/**
	 * @return base BaseRepository
	 */
	@Override
	public BaseRepository<User, Long> getBaseRepository() {
		return this.userRepository;
	}

	/**
	 * find by page. SQL: SELECT * FROM user WHERE 1=1 AND (user_name LIKE
	 * '%[queryBean.getUsername()]%' OR '[queryBean.getUsername()]' IS NULL OR
	 * '[queryBean.getUsername()]' = '') AND (status LIKE
	 * '%[queryBean.getStatus()]%' OR '[queryBean.getStatus()]' IS NULL OR
	 * '[queryBean.getStatus()]' = '')
	 * 
	 * @param queryBean   query
	 * @param pageRequest pageRequest
	 * @return page
	 */
	@Override
	public Page<User> findPage(UserQueryBean queryBean, PageRequest pageRequest) {

		// 1. 构建单个条件的Specification
		Specification<User> nameSpec = (root, criteriaQuery, criteriaBuilder) -> {
			if (StringUtils.isEmpty(queryBean.getUsername())) {
				return criteriaBuilder.conjunction(); // 条件为空时，返回"1=1"（不影响其他条件）
			}
			// 模糊匹配：user_name LIKE %xxx%
			return criteriaBuilder.like(root.get("username"), "%" + queryBean.getUsername() + "%");
		};

		Specification<User> descSpec = (root, criteriaQuery, criteriaBuilder) -> {
			if (StringUtils.isEmpty(queryBean.getStatus())) {
				return criteriaBuilder.conjunction();
			}
			return criteriaBuilder.like(root.get("status"), "%" + queryBean.getStatus() + "%");
		};

		// 2. 组合条件（AND连接）
		Specification<User> spec = Specification.where(nameSpec).and(descSpec);

		return this.getBaseRepository().findAll(spec, pageRequest);
	}

	// 用Stream流對取得的數據進行流式處理
	@Override
	public List<User> streamStu() {
		System.out.println("********************StreamTest********************");
		List<User> userList = userRepository.findAll();
		List<User> collect = userList.stream().filter(user -> user.getId() < 50).collect(Collectors.toList());
		return collect;

	}

	@Override
	public List<User> findByIdCreateByUsername() {
		System.out.println("********************Specification********************");
		Specification<User> spec = (root, criteriaQuery, criteriaBuilder) -> {
			// 首先通过root获取查询语句中的各个字段。其中注意两点->1：泛型是该字段的数据类型。2：get()中的字段必须是实体类中的属性名。
			Path<Long> id = root.get("id");
			Path<String> createBy = root.get("createBy");
			Path<String> username = root.get("username");

			// 其次使用criteriaBuilder对上方各个字段设置条件。
			// 条件
			// 1.id>=150; 2.create_by="ADMIN"; 3.username="B%"
			Predicate greaterThanOrEqualTo = criteriaBuilder.greaterThanOrEqualTo(id, 150L);
			Predicate equal = criteriaBuilder.equal(createBy, "ADMIN");
			Predicate likeb = criteriaBuilder.like(username, "B%");
			Predicate liked = criteriaBuilder.like(username, "D%");
			// ⚪动态查询： 如果create_by为空那就找username为D开头的
			if (createBy != null) {
				return criteriaBuilder.and(greaterThanOrEqualTo, liked);
			}

			// 最后通过criteriaBuilder来拼接上方设定好的条件（比如：AND OR...）
			Predicate predicate = criteriaBuilder.and(greaterThanOrEqualTo, equal, likeb);

			// 没有orderby或者DESC ASC（排序）的话直接return，有的话通过criteriaQuery实现
			// 比如： return criteriaQuery.where(predicate).orderBy(desc).getRestriction();
			return predicate;

		};
		List<User> findAll = userRepository.findAll(spec);
		for (User list : findAll) {
			System.out.println(list);
		}
		return findAll;

	}

//
//	/*
//	 * 点赞功能，之后加端末MAC判断？或者账户判断
//	 */
//    @Override
//    @Transactional
//    public User decreaseLikes(Long id) {
//        // 检查用户是否存在
//        User user = userMapper.findUserById(id);
//        if (user == null) {
//            throw new EntityNotFoundException("用户不存在: " + id);
//        }
//        
//        // 执行点赞数减少
//        int affected = userMapper.decreaseLikes(id);
//        if (affected <= 0) {
//            throw new RuntimeException("更新点赞数失败");
//        }
//        
//        // 重新查询获取最新数据
//        return userMapper.findUserById(id);
//    }
//	
}
