/**
 * 
 */
package com.test.demo.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.test.demo.entity.User;

/**
 * @author 70998115
 *
 */
//@Repository
//@Mapper
public interface UserMapper {
	
	//Select where
	User findUserById(Long id);
	
	//insert
	int addUser(User user);
	
	//Select *
	List<User> getUserList();
	
	//Update by id
	void updateById(Long id);
	
	//delete by id
	void deleteById(Long id);
	
	//like up
	int increaseLikes(Long id);
	
	//like down
	int  decreaseLikes(Long id);

}
