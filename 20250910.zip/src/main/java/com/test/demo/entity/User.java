/**
 * 
 */
package com.test.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.ColumnDefault;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * @author 70998115 用户登录使用
 */

@Data
@Entity
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Table(name = "sys_user")
public class User extends BaseEntity {

	// 反序列化
	private static final long serialVersionUID = 1L;

	/** 主键 */
	@Id
	@Column(name = "id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY) // PostgreSQL自增主键
	private Long id;

	/** 用户名 */
	@Column(name = "username", length = 50, nullable = false, unique = true)
	private String username;

	/** 密码 */
	@Column(name = "password", length = 100, nullable = false)
	private String password;

	/** 手机号 */
	@Column(name = "phone", length = 11)
	private String phone;

	/** 邮箱 */
	@Column(name = "email", length = 100)
	private String email;

	/** 账户状态：0:禁用, 1:启用 */
	@Column(name = "status", length = 1) // 默认账户可用
	@ColumnDefault("'1'")
	private String status;

	/** 通过用户名和电话查找User */
	public User(String username, String password, String phone) {
		this.username = username;
		this.password = password;
		this.phone = phone;
	}

}
