/**
 * 
 */
package com.test.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Min;

import org.hibernate.annotations.ColumnDefault;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @author 70998115 分类code表
 */
@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Table(name = "code_goods_category")
public class GoodsCategory extends BaseEntity {

	// 反序列化
	private static final long serialVersionUID = 1L;

	/** 分类id */
	@Id
	@Column(name = "id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY) // PostgreSQL自增主键
	private int id;

	/** 上级分类id,若值为0，表示上级分类是根节点。 */
	@Min(value = 0, message = "数值不能为负数") // 确保数值≥0（类似无符号语义）
	@Column(name = "parentid", length = 10, nullable = false)
	private int parentId;

	/** 分类名称 */
	@Column(name = "name", length = 100, nullable = false)
	private String name;

	/** 排序：用于对同级分类进行排序，按照从小到大的顺序排列。 */
	@Min(value = 0, message = "数值不能为负数") // 确保数值≥0（类似无符号语义）
	@Column(name = "sort", length = 11, nullable = false)
	private int sort;

	/** 是否显示：0表示不显示，1表示显示。 */
	@Column(name = "isshow", length = 1, nullable = false)
	@ColumnDefault("'1'")
	private String isShow;

}
