/**
 * 
 */
package com.test.demo.entity;

/**
 * @author 70998115
 * 使用方式：
 * 		Gender gender = Gender.getById(2);
 *		System.out.println( gender.getLabel() );	//女
 *
 */
public enum Gender {

	M("男", 1),
	F("女", 2),
	N("未知", 3);

	private String label;
	private int id;


	private Gender(String label, int id) {
		this.label = label;
		this.id = id;
	}


	public String getLabel() {
		return label;
	}

	public int getId() {
		return id;
	}


	public static Gender getById(int id) {

		for( Gender gender : Gender.values() ) {	//拡張for文による走査
			if( gender.getId() == id ) {
				return gender;					//条件に一致するインスタンスを返す
			}
		}
		return null;
	}
}
