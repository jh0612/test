/**
 * 
 */
package com.test.demo.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.CreationTimestamp;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @author 70998115
 *
 */
@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Table(name = "tb_customer")
public class Customer extends BaseEntity {

	// 反序列化
	private static final long serialVersionUID = 1L;

	/** 唯一标识客户的主键 */
	@Id
	@Column(name = "customerid", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY) // PostgreSQL自增主键
	private Long customerId;

	/** 用户表的用户名 */
	@Column(name = "customer_username", length = 50, nullable = false, unique = true)
	private String customerUsername;

	/** 客户姓名 */
	@Column(name = "customer_name", length = 45, nullable = false)
	private String customerName;

	/** 客户性别：'M'男 'F'女 'N'未知 */
	@Column(name = "customer_gender", nullable = false)
	@ColumnDefault("'N'")
	private String customerGender;

	/** 客户年龄 */
	@Column(name = "customer_age", length = 3, nullable = false)
	@ColumnDefault("'0'")
	private String customerAge;

	/** 客户手机号码 */
	@Column(name = "customer_phone", length = 11, nullable = false)
	@ColumnDefault("'99999999999'")
	private String customerPhone;

	/** 客户电子邮件 */
	@Column(name = "customer_email", length = 100, nullable = false)
	@ColumnDefault("'test@163.com'")
	private String customerEmail;

	/** 客户住址 */
	@Column(name = "customer_address", length = 255, nullable = true)
	@ColumnDefault("''")
	private String customerAddress;

	/** 客户头像 */
	@Column(name = "customer_image", length = 255, nullable = true)
	@ColumnDefault("''")
	private String customerImage;

	/** 客户职业 */
	@Column(name = "customer_occupation", length = 100, nullable = true)
	@ColumnDefault("''")
	private String customerOccupation;

	/** 客户注册时间 */
	@CreationTimestamp // 创建时间，插入时自动生成
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@Column(name = "customer_register_time", nullable = false, updatable = false)
	private Date customerRegisterTime;

}
