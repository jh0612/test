/**
 * 
 */
package com.test.demo.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.Transient;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

/**
 * @author 70998115 基础实体类，包含通用的创建时间和更新时间字段
 */
@Data
@MappedSuperclass // 标识该类为父类，不会生成单独的表
public class BaseEntity implements Serializable {
	// 反序列化
	private static final long serialVersionUID = 1L;

	/** 搜索值 */
	@Column(name = "search_value", updatable = false, insertable = false)
	private String searchValue;

	/** 删除FLG */
	@Column(name = "is_deleted", nullable = false)
	private char isDeleted = '0'; // 默认未删除

	/** 创建者 */
	@Column(name = "create_by", length = 64)
	private String createBy;

	/** 创建时间 */
	@CreationTimestamp // 创建时间，插入时自动生成
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@Column(name = "create_time", nullable = false, updatable = false)
	private Date createTime;

	/** 更新者 */
	@Column(name = "update_by", length = 64)
	private String updateBy;

	/** 更新时间 */
	@UpdateTimestamp // 更新时间，插入和更新时自动生成
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@Column(name = "update_time")
	private Date updateTime;

	/** 备注 */
	@Column(name = "remark")
	private String remark;

	/** 请求参数 */
	// 当一些没有这些字段的时候，可以存在map
	@Transient
	private Map<String, Object> params;

	public Map<String, Object> getParams() {
		if (params == null) {
			params = new HashMap<>();
		}
		return params;
	}
}