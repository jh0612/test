/**
 * 
 */
package com.test.demo.entity;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @author 70998115
 *
 */
@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Table(name = "tb_product")
public class Product extends BaseEntity {

	// 反序列化
	private static final long serialVersionUID = 1L;

	/** 商品ID */
	@Id
	@Column(name = "productid", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY) // PostgreSQL自增主键
	private Long productId;

	/** 商品编号 */
	@Column(name = "product_productid", length = 20, nullable = false, unique = true)
	private String productProductId;

	/** 商品名 */
	@Column(name = "product_name", length = 120, nullable = false)
	private String productName;

	/** 商品分类 */
	@Column(name = "product_type", length = 3, nullable = false)
	private String productType;

	/** 进货价 */
	@Column(name = "product_cost", nullable = false, precision = 10, scale = 2)
	@ColumnDefault("0.0")
	private BigDecimal productCost;

	/** 售价 */
	@Column(name = "product_price", nullable = false, precision = 10, scale = 2)
	@ColumnDefault("0.0")
	private BigDecimal productPrice;

	/** 商品品牌 */
	@Column(name = "product_brand", length = 3, nullable = false)
	private String productBrand;

	/** 库存 */
	@Column(name = "product_inventory", length = 11, nullable = false)
	@ColumnDefault("0")
	private int productInventory;

	/** 保质期（19991231：无期限） */
	@Column(name = "product_shelflife", length = 8, nullable = false) // 默认值字符串需要单引号包裹
	@ColumnDefault("'19991231'")
	private String productShelflife;

	/** 商品描述 */
	@Column(name = "product_description", length = 255, nullable = false)
	private String productDescription;

	/** 商品图片 */
	@Column(name = "product_image", length = 255, nullable = false)
	@ColumnDefault("'http://xxxxxxx/img/1.jpg'")
	private String productImage;

	/** 商品上架时间 */
	@CreationTimestamp // 创建时间，插入时自动生成
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@Column(name = "product_launch_time", nullable = false, updatable = false)
	private Date productLaunchTime;

	/** 商品更新时间 */
	@UpdateTimestamp // 更新时间，插入和更新时自动生成
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@Column(name = "product_update_time")
	private Date productUpdateTime;

	/** 商品状态 */
	@Column(name = "product_status", length = 2, nullable = false)
	private String productStatus;

	/** 商品销量 */
	@Column(name = "product_sales", length = 11, nullable = false)
	@ColumnDefault("0")
	private int productSales;

	/** 商品评分 */
	@Column(name = "product_rating", length = 11, nullable = false)
	@ColumnDefault("100")
	private int productRating;

	/** 商品标签 */
	@Column(name = "product_tag", length = 8, nullable = false)
	private String productTag;

}
