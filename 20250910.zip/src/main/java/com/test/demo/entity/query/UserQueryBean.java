package com.test.demo.entity.query;

import lombok.Builder;
import lombok.Data;

/**
 * 用于封装User相关的查询条件 1 查询条件封装： 集中存放与用户查询相关的参数（如名称、描述），避免在方法参数中传递多个零散的查询条件。 2
 * 提高代码可读性和可维护性： 用一个专门的类来承载查询条件，比在方法签名中罗列多个参数更清晰，后续新增查询条件时只需在类中添加字段即可。 3
 * 支持灵活的查询组合： 可以根据需要设置不同的字段值，实现多条件组合查询（例如：按名称查询、按描述查询、或两者结合查询）。 4 与构建者模式配合使用：
 * 由于添加了@Builder注解，可以非常方便地创建查询对象并设置所需的查询条件 5 数据传输载体：
 * 通常用于在控制层（Controller）和服务层（Service）之间传递查询参数
 * 
 * @author 70998115
 *
 */
@Data
@Builder // https://blog.csdn.net/Mrxiao_bo/article/details/140228527
public class UserQueryBean {

	/**
	 * contains username pattern.
	 */
	private String username;

	/**
	 * contains status pattern.
	 */
	private String status;

}