/**
 * 
 */
package com.test.demo.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @author 70998115
 *
 */
@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Table(name = "tb_pets")
public class Pets extends BaseEntity {

	// 反序列化
	private static final long serialVersionUID = 1L;

	/** 主键 */
	@Id
	@Column(name = "petsid", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY) // PostgreSQL自增主键
	private Long petsId;

	/** 主人customerId */
	@Column(name = "pets_customerid", length = 9, nullable = false)
	private Long petsCustomerId;

	/** pet名字 */
	@Column(name = "pets_name", length = 45, nullable = false)
	private String petsName;

	/** pet年龄 */
	@Column(name = "pets_age", length = 2, nullable = false)
	@ColumnDefault("'0'")
	private String petsAge;

	/** pet性别 */
	@Column(name = "pets_sex", length = 1, nullable = false)
	@ColumnDefault("'1'")
	private String petsSex;

	/** 绝育（0：没做过 1：做过） */
	@Column(name = "pets_neutered", length = 1, nullable = false)
	@ColumnDefault("'0'")
	private String petsNeutered;

	/** 疫苗情况（0针，1针，2针，3针,9不明） */
	@Column(name = "pets_vaccinesituation", length = 1, nullable = false)
	@ColumnDefault("'9'")
	private String petsVaccineSituation;

	/** 健康状况（0活泼，1正常，2要观察，3较差，4生病中） */
	@Column(name = "pets_health_status", length = 1, nullable = false)
	@ColumnDefault("'1'")
	private String petsHealthStatus;

	/** 寄养情况（0：寄养中；1：已接走） */
	@Column(name = "pets_fostercare_status", length = 1, nullable = false)
	@ColumnDefault("'0'")
	private String petsFostercareStatus;

	/** 寄养开始日 */
	@CreationTimestamp // 创建时间，插入时自动生成
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@Column(name = "pets_foster_start_date", nullable = false, updatable = false)
	private Date petsFosterStartdate;

	/** 寄养结束日 */
	@UpdateTimestamp // 更新时间，插入和更新时自动生成
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@Column(name = "pets_foster_end_date")
	private Date petsFosterEnddate;

}
