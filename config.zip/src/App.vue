
<template>
  <div id="app">
    <h1 class="MyName">Test Demo</h1>
    <nav>
      <router-link to="/">排行</router-link> |
      <router-link to="/Newest">最新</router-link> |
      <router-link to="/Random">随机</router-link>
    </nav>
    <router-view />
    <!-- <InputText /> -->
    <!-- <div class="newText">列表仅显示50条内容</div> -->
  </div>
</template>

<script>
import InputText from '@/components/InputText.vue'

export default {
  name: 'App',
  components: {
    InputText
  }
}
</script>

<style>
#app {
font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
</style>
