
<template>
  <div id="app">
    <el-menu :default-active="activeIndex2" class="el-menu-demo" mode="horizontal" @select="handleSelect" background-color="#545c64" text-color="#fff" active-text-color="#ffd04b">
      <el-menu-item index="1"><router-link to="/">排行</router-link></el-menu-item>
      <el-menu-item index="2"><router-link to="/Newest">最新</router-link></el-menu-item>
      <el-menu-item index="3"><router-link to="/Random">随机</router-link></el-menu-item>
      <el-menu-item index="4" disabled>消息中心</el-menu-item>
    </el-menu>
    <router-view />
    <!-- <InputText /> -->
    <!-- <div class="newText">列表仅显示50条内容</div> -->
  </div>
</template>

<script>
import InputText from '@/components/InputText.vue'

export default {
  name: 'App',
  components: {
    InputText
  }
}
</script>

<style>
#app {
font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
</style>
