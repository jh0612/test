<!-- InputText.vue 组件作为发送内容的组件，包括一个输入框和一个发送按钮。-->
<template>
  <div class="InputText">
  <el-form :inline="true" :model="formInline" class="demo-form-inline">
  <el-form-item label="ID">
    <el-input v-model="formInline.id" placeholder="ID"></el-input>
  </el-form-item>
  <el-form-item label="年齡">
    <el-input v-model="formInline.age" placeholder="年齡"></el-input>
  </el-form-item>
  <el-form-item label="姓名">
    <el-input v-model="formInline.name" placeholder="姓名"></el-input>
  </el-form-item>
  <el-form-item>
    <el-button type="primary" @click="onSubmit">追加</el-button>
  </el-form-item>
</el-form>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'InputText',
  data () {
    return {
      formInline: {
        id: '',
        user: '',
        name: ''
      }
    }
  },

  methods: {
    onSubmit () {
      if (!this.formInline.id == null || !this.formInline.age == null || !this.formInline.name == null) {
        this.$message.warning('情報不足、補足してください。')
        return
      }

      let url = 'http://localhost:8081/api/user/addUser'
      // let list = []

      axios.post(url, this.formInline).then(response => {
        console.log(response.data)
        if (response.data === 1) {
          // Vue.prototype.$message({
          //   message: '追加しました。',
          //   type: 'success'
          // })
          console.log('444444444')
          // 至少刷新了
          this.$router.go(0)
          // ：通过事件通知父组件刷新数据--->没实现
          // this.$emit('listRef', {id: this.formInline.id, age: this.formInline.age, name: this.formInline.name}) // 触发事件
          this.formInline = {
            id: '',
            age: '',
            name: ''
          }
        } else {
          console.log('333333333')
          this.Vue.prototype.$message({
            message: '追加できませんでした。もう一度試してみてください。',
            type: 'error'
          })
          // alert("添加失败！")
        }
      })
        .catch(error => {
          console.error('请求失败:', error)
          this.Vue.prototype.$message({
            message: '网络请求失败，请稍后重试',
            type: 'error'
          })
        })
    }
  }
}
</script>
