<template>
  <div class="user-component">
    <h3>用户管理</h3>
    <el-table :data="userList" border style="width: 100%; margin-top: 20px;">
      <el-table-column prop="id" label="ID" width="80"></el-table-column>
      <el-table-column prop="name" label="姓名"></el-table-column>
      <el-table-column prop="role" label="角色"></el-table-column>
      <el-table-column prop="status" label="状态">
        <template slot-scope="scope">
          <el-tag :type="scope.row.status === 'active' ? 'success' : 'danger'">
            {{ scope.row.status === 'active' ? '活跃' : '禁用' }}
          </el-tag>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
export default {
  name: 'UserComponent',
  data () {
    return {
      userList: [
        { id: 1, name: '张三', role: '管理员', status: 'active' },
        { id: 2, name: '李四', role: '普通用户', status: 'active' },
        { id: 3, name: '王五', role: '访客', status: 'danger' }
      ]
    }
  }
}
</script>

<style scoped>
.user-component {
  padding: 10px 0;
}
</style>
