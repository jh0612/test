<template>
  <div class="user-operations">
    <!-- 编辑按钮 -->
    <el-button size="mini" type="primary" @click="openEditDialog">编辑</el-button>

    <!-- 编辑对话框 -->
    <el-dialog title="编辑用户" :visible.sync="dialogFormVisible" append-to-body>
      <el-form :model="form">
        <el-form-item label="ID" :label-width="formLabelWidth">
          <el-input v-model="form.id" disabled></el-input>
        </el-form-item>
        <el-form-item label="年龄" :label-width="formLabelWidth">
          <el-input v-model="form.age"></el-input>
        </el-form-item>
        <el-form-item label="姓名" :label-width="formLabelWidth">
          <el-input v-model="form.name"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer">
        <el-button @click="dialogFormVisible = false">取消</el-button>
        <el-button type="primary" @click="handleEdit">确定</el-button>
      </div>
    </el-dialog>

    <!-- 删除按钮 -->
    <el-button size="mini" type="danger" @click="handleDelete">删除</el-button>

    <!-- 点赞按钮 -->
    <el-button
      size="mini"
      :icon="isLiked ? 'el-icon-star-on' : 'el-icon-star-off'"
      @click="toggleLike"
      :type="isLiked ? 'success' : ''"
    >
      {{ user.likes }}
    </el-button>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'UserList',
  props: {
    user: {
      type: Object,
      required: true,
      default: () => ({})
    }
  },
  data () {
    return {
      dialogFormVisible: false,
      form: {
        id: '',
        age: '',
        name: ''
      },
      formLabelWidth: '100px'
    }
  },
  computed: {
    // 计算当前用户的点赞状态
    isLiked () {
      return localStorage.getItem(`isLiked${this.user.id}`) === 'true'
    }
  },
  methods: {
    // 打开编辑对话框并初始化数据
    openEditDialog () {
      this.form = { ...this.user }
      this.dialogFormVisible = true
    },

    // 处理编辑提交
    handleEdit () {
      axios.patch(`http://localhost:8081/api/user/editUser/${this.form.id}`, {
        age: this.form.age,
        name: this.form.name
      }).then(() => {
        this.$emit('update-user', this.form)
        this.dialogFormVisible = false
        this.$message.success('修改成功！')
      }).catch(error => {
        console.error('修改失败:', error)
        this.$message.error('修改失败，请重试')
      })
    },

    // 处理删除
    handleDelete () {
      axios.delete(`http://localhost:8081/api/user/delete/${this.user.id}`)
        .then(() => {
          this.$emit('delete-user', this.user.id)
          this.$message.success('删除成功')
        })
        .catch(error => {
          console.error('删除失败:', error)
          this.$message.error('删除失败，请重试')
        })
    },

    // 处理点赞切换
    toggleLike () {
      const action = this.isLiked ? 'decreaseLikesById' : 'increaseLikesById'
      axios.put(`http://localhost:8081/api/user/${action}/${this.user.id}`)
        .then(res => {
          const updatedUser = { ...this.user, likes: res.data.likes }
          this.$emit('update-user', updatedUser)
          localStorage.setItem(`isLiked${this.user.id}`, !this.isLiked)
        })
        .catch(error => {
          console.error('点赞操作失败:', error)
        })
    }
  }
}
</script>
