<!-- UserList.vue 组件作为单个用户发送的内容，上面显示省份与点赞等内容。 -->

<template>
<div class="UserList">
    <div class="box">
      <div class="box1">
        <!-- <div class="id">{{id}}</div>
        <div class="age">{{age}}</div>
        <div class="name">{{name}}</div> -->
         <el-table
      :data="tableData"
      style="width: 100%">
      <el-table-column
        prop="id"
        label="ID"
        width="180">
      </el-table-column>
      <el-table-column
        prop="age"
        label="年齡"
        width="180">
      </el-table-column>
      <el-table-column
        prop="name"
        label="姓名">
      </el-table-column>
      <el-table-column
        fixed="right"
        label="操作">
      <template slot-scope="scope">
        <!-- dialogで情報編集する -->
        <el-button size="mini" type="text" @click="dialogFormVisible = true">编辑</el-button>

        <el-dialog title="ユーザー情報" :visible.sync="dialogFormVisible" append-to-body>
          <el-form :model="form">
            <el-form-item label="id" :label-width="formLabelWidth">
              <el-input v-model="form.id" autocomplete="off" :disabled="true"></el-input>
            </el-form-item>
            <el-form-item label="age" :label-width="formLabelWidth">
              <el-input v-model="form.age" autocomplete="off"></el-input>
            </el-form-item>
            <el-form-item label="name" :label-width="formLabelWidth">
              <el-input v-model="form.name" autocomplete="off"></el-input>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="dialogFormVisible = false">取 消</el-button>
            <el-button type="primary" @click="handleEdit(form,scope.row)">确 定</el-button>
          </div>
        </el-dialog>
        <!-- ただのバタン -->
        <!-- <el-button
          size="mini"
          @click="handleEdit(scope.$index, scope.row)">编辑</el-button> -->
        <el-button
          size="mini"
          type="danger"
          @click="handleDelete(scope.row)">删除</el-button>
      </template>
      </el-table-column>
    </el-table>
      </div>
      <div class="box2">
        <!-- <div class="province">{{province}}</div>
        <div class="likes">{{likes}}</div> -->

        <!-- <img
          :src="imagePath"
          @click="toggleImage"
          class="img-btn"
        /> -->
      </div>
    </div>
</div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'UserList',
  props: {
    Obj: Object
  },
  data () {
    return {
      imagePath: require('@/assets/点赞-no.png'),
      tableData: [],
      // 以下はdialog必須内容
      dialogFormVisible: false,
      form: {
        id: this.Obj.id,
        age: this.Obj.age,
        name: this.Obj.name
      },
      formLabelWidth: '100px'
    }
  },
  created () {
    // 无论是否点赞，都要初始化表格数据
    this.tableData = [this.Obj]
    // 检查本地存储中的点赞状态
    if (localStorage.getItem(`isLiked${this.Obj.id}`)) {
      this.imagePath = require('@/assets/点赞-yes.png')
    }
  },
  methods: {
    // 情報編集メソッド
    // form是修改后数据，row是修改前数据
    handleEdit (form, row) {
      console.log(row.id)
      axios.patch('http://localhost:8081/api/user/editUser/' + row.id, {
        age: form.age,
        name: form.name
      }).then(() => {
        axios.get('http://localhost:8081/api/user').then(response => { // 刷新页面
          this.tableData = response.data
        })
      })
      console.log(form.id)
      this.dialogFormVisible = false
    },
    // 情報削除メソッド
    handleDelete (row) {
      // console.log(index, row)
      console.log(row)
      console.log(row.id)
      axios.delete('http://localhost:8081/api/user/delete/' + row.id).then(() => {
        axios.get('http://localhost:8081/api/user').then(response => { // 刷新页面
          this.tableData = response.data
        })
      })
    },
    toggleImage () {
      // 判断是否点赞过
      if (this.imagePath === require('@/assets/点赞-no.png')) {
        // 获取按钮元素
        const imgBtn = this.$el.querySelector('.img-btn')
        // 给按钮元素应用缩放和旋转的样式
        imgBtn.style.transform = 'scale(1.2) rotate(-10deg)'
        // 设置计时器，在 300 毫秒之后给按钮元素应用新的样式
        setTimeout(() => {
          imgBtn.style.transform = 'scale(1) rotate(10deg)'
          setTimeout(() => {
            imgBtn.style.transform = 'scale(1) rotate(0deg)'
          }, 300)
        }, 300)

        this.likes++

        // 将图片替换为已点赞的图片
        this.imagePath = require('@/assets/点赞-yes.png')
        // 将已点赞的状态存入 localStorage
        localStorage.setItem(`isLiked${this.Obj.id}`, true)

        // 向服务器发送发送put请求
        axios.put(`http://localhost:8087/increaseLikesById/${this.Obj.id}`)
          .then(res => {
            console.log(res.data)
          })
          .catch(error => {
            console.log('点赞出错！')
            console.error(error)
          })
      } else {
        this.likes--

        // 否则将图片替换为未点赞的图片
        this.imagePath = require('@/assets/点赞-no.png')
        // 并且删除已点赞的状态
        localStorage.removeItem(`isLiked${this.Obj.id}`)

        // 向服务器发送发送put请求
        axios.put(`http://localhost:8087/decreaseLikesById/${this.Obj.id}`)
          .then(res => {
            console.log(res.data)
          })
          .catch(error => {
            console.log('取消点赞出错！')
            console.error(error)
          })
      }
    }
  }

}
</script>
