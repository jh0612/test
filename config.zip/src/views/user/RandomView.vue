<!-- src/views/RandomView.vue -->
<template>
  <div class="random-view">
    <h1>按隨機排序的内容</h1>
  </div>
</template>

<script>
export default {
  name: 'RandomView'
}
</script>
