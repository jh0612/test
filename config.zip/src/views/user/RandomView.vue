<!-- src/views/RandomView.vue -->
<!--
后台管理端功能：
1.用户管理（当前注册后的用户的权限，改密码等（当前在线人数。。）的管理）
2.客户管理（客户基本信息查询，客户宠物信息查询，寄养状态修改等）
3.当前店内商品的增删改查（库存什么的。。简单的就行）
4.实体店铺信息简单信息修改
5.监控视频模块后台实时
6.单独登录页面（不与客户用的小程序端共用）
-->
<template>
  <div class="admin-layout">
    <!-- 顶栏 -->
    <el-header class="layout-header">
      <!-- 移动端菜单按钮 -->
      <el-button icon="el-icon-menu" size="mini" class="menu-toggle" @click="toggleSidebar" v-show="isMobile"></el-button>
      <!-- 系统标题 -->
      <div class="system-title" v-show="!isMobile">Test 系统</div>
      <!-- 右侧用户区域（固定在右上角） -->
      <div class="user-area">
        <el-dropdown trigger="click">
          <span class="user-info cursor-pointer">
            <img src="D:\3_vscodeproject\TestVueNew\demo\src\assets\logo.png" class="user-avatar" alt="用户头像">
            <span class="user-name" v-show="!isMobile">管理员</span>
            <i class="el-icon-arrow-down el-icon--small"></i>
          </span>
          <el-dropdown-menu slot="dropdown" align="right">
            <el-dropdown-item>个人中心</el-dropdown-item>
            <el-dropdown-item>退出登录</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </div>
    </el-header>

    <div class="layout-main">
      <!-- 2. 侧栏 -->
      <el-aside class="layout-sidebar" :class="{ 'sidebar-hidden': isMobile && !showSidebar }">
        <el-menu default-active="currentView" mode="vertical" background-color="#2d3a4b"
        text-color="#fff" active-text-color="#409eff" @select="handleMenuSelect"><!-- @select="handleMenuSelect"：点击菜单切换组件 -->
          <el-menu-item index="/dashboard">
            <i class="el-icon-s-home"></i>
            <span slot="title">首页</span>
          </el-menu-item>
          <el-submenu index="system">
            <template slot="title">
              <i class="el-icon-setting"></i>
              <span slot="title">系统管理</span>
            </template>
            <el-menu-item index="user">用户管理</el-menu-item><!--index中因为是切换组件所以给个名字而不是路径-->
            <el-menu-item index="/system/role">角色管理</el-menu-item>
          </el-submenu>
          <el-submenu index="customer">
            <template slot="title">
              <i class="el-icon-user-solid"></i>
              <span slot="title">客户管理</span>
            </template>
            <el-menu-item index="/customer/info">客户情报</el-menu-item>
            <el-menu-item index="/customer/pets">爱宠管理</el-menu-item>
          </el-submenu>
          <el-submenu index="products">
            <template slot="title">
              <i class="el-icon-s-goods"></i>
              <span slot="title">商品管理</span>
            </template>
            <el-menu-item index="/products/new">新增商品</el-menu-item>
            <el-menu-item index="/products/inventory">库存管理</el-menu-item>
            <el-menu-item index="/products/price">价格管理</el-menu-item>
          </el-submenu>
          <el-menu-item index="/surveillance">
            <i class="el-icon-video-camera-solid"></i>
            <span slot="title">监控模块</span>
          </el-menu-item>
          <el-menu-item index="/storeinfo">
            <i class="el-icon-s-shop"></i>
            <span slot="title">店铺信息（记录及修改）</span>
          </el-menu-item>
        </el-menu>
      </el-aside>

      <!-- 3. 内容区 -->
      <el-main class="layout-content">
        <div class="content-inner">
          <!-- Skeleton 骨架屏 -->
          <!-- <el-skeleton :rows="6" animated />
          <h3>内容展示区</h3>
          <p>根据路由加载对应页面内容</p> -->
           <component :is="currentComponent"></component>
        </div>
      </el-main>
    </div>
  </div>
</template>

<script>
// 导入需要在右侧显示的组件
import Dashboard from '@/components/Dashboard.vue'// dashboard也需要
import User from '@/components/User.vue'// 以user为例别的还没开发

export default {
  name: 'RandomView',
  props: {
    // 接收路由参数中的 currentView（默认显示 dashboard）
    currentView: {
      type: String,
      default: 'dashboard'
    }
  },
  data () {
    return {
      isMobile: false, // 是否移动端
      showSidebar: true, // 侧边栏是否显示（移动端）
      // 组件映射表：key 对应菜单 index，value 对应组件
      componentMap: {
        dashboard: Dashboard,
        user: User
        // role: Role,
        // business: Business
      }
    }
  },
  computed: {
    // 根据当前 currentView 动态返回组件
    currentComponent () {
      return this.componentMap[this.currentView] || Dashboard
    }
  },
  mounted () {
    // 初始化判断设备
    this.checkDevice()
    window.addEventListener('resize', this.checkDevice)
  },
  beforeDestroy () {
    window.removeEventListener('resize', this.checkDevice)
  },
  methods: {
    // 检查设备类型（768px为分界）
    checkDevice () {
      this.isMobile = window.innerWidth < 768
      // 移动端默认隐藏侧边栏
      if (this.isMobile) this.showSidebar = false
      else this.showSidebar = true
    },
    // 切换侧边栏显示/隐藏（移动端）
    toggleSidebar () {
      this.showSidebar = !this.showSidebar
    },
    // 菜单点击事件：切换当前显示的组件
    handleMenuSelect (index) {
      this.currentView = index
      // 可选：更新 URL 参数（不跳转页面，仅更新 query）
      this.$router.push({
        path: '/Random', // 这里如果登陆后的url是在根目录下的话“/”那就需要改为“/”
        query: { ...this.$route.query, view: index }
      })
      // 移动端点击菜单后隐藏侧栏
      if (this.isMobile) this.showSidebar = false
    }
  }
}
</script>

<style scoped>
/* 全局布局容器 */
.admin-layout {
  width: 100%;
  height: 100vh;
  overflow: hidden;
}

/* 1. 顶栏样式 */
.layout-header {
  height: 50px !important;
  line-height: 50px;
  background-color: #fff;
  box-shadow: 0 1px 4px rgba(0,0,0,0.1);
  padding: 0 20px;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 10;
  /* 关键：使用flex布局确保左右区域分离 */
  display: flex;
  justify-content: space-between;
  align-items: center;
}

/* 顶栏左侧区域 */
.header-left {
  display: flex;
  align-items: center;
}

.system-title {
  font-size: 16px;
  font-weight: 600;
  color: #2d3a4b;
  margin-left: 10px;
}

.menu-toggle {
  background: transparent;
  border: none;
  cursor: pointer;
}

/* 2. 用户区域（固定在右上角） */
.user-area {
  /* 关键：固定在右侧，不受左侧内容影响 */
  margin-left: auto;
  padding-left: 20px;
}

.user-info {
  display: inline-flex;
  align-items: center;
  vertical-align: middle;
}

.user-avatar {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  vertical-align: middle;
}

.user-name {
  margin: 0 5px;
  font-size: 14px;
}

.cursor-pointer {
  cursor: pointer;
}

/* 3. 主容器（侧栏+内容区） */
.layout-main {
  display: flex;
  height: calc(100vh - 50px);
  margin-top: 50px;
}

/* 4. 侧栏样式 */
.layout-sidebar {
  width: 100px;
  background-color: #2d3a4b;
  position: fixed;
  top: 50px;
  bottom: 0;
  left: 0;
  z-index: 5;
}

/* 移动端隐藏侧栏 */
.sidebar-hidden {
  display: none;
}

/* 5. 内容区样式 */
.layout-content {
  flex: 1;
  padding: 20px;
  margin-left: 300px;
  background-color: #f5f7fa;
  overflow-y: auto;
}

/* 移动端适配：内容区占满宽度 */
@media (max-width: 768px) {
  .layout-content {
    margin-left: 0;
    padding: 10px;
  }

  /* 移动端用户区域仅显示头像 */
  .user-name {
    display: none;
  }
}

/* 内容区内部容器 */
.content-inner {
  background-color: #fff;
  padding: 20px;
  border-radius: 4px;
  min-height: 300px;
}
</style>
