<!-- src/views/LikesSortedView.vue -->
<template>
   <div class="PaiHang">
    <InputText @listRef="created"/>
    <UserList
      v-for="(item, index) in Obj"
      :key="index"
      :Obj="item"
    />
    <!-- 下面放開做分頁 -->
    <!-- <el-button-group>
  <el-button type="primary" icon="el-icon-arrow-left">上一页</el-button>
  <el-button type="primary">下一页<i class="el-icon-arrow-right el-icon--right"></i></el-button>
</el-button-group>
<el-button-group>
  <el-button type="primary" icon="el-icon-edit"></el-button>
  <el-button type="primary" icon="el-icon-share"></el-button>
  <el-button type="primary" icon="el-icon-delete"></el-button>
</el-button-group> -->
  </div>
</template>

<script>
// @ 是 /src 的别名
import UserList from '@/components/UserList.vue'
import InputText from '@/components/InputText.vue'
import axios from 'axios'

export default {
  name: 'LikesSortedView',
  components: {
    UserList,
    InputText
  },

  data () {
    return {
      Obj: []
    }
  },

  // computed会缓存结果，methods每次都会重新计算
  methods: {
    // 新規情報メソッド
    handleAddItem (formInline) {
    // 生成唯一ID
    //   formInline.id = Date.now();
    // 添加到数据列表，会自动更新ListComponent
      console.log(formInline)
      this.Obj.push(formInline)
    // 如果需要强制刷新（通常不需要，因为Vue是响应式的）
    // this.dataList = [...this.dataList];
    },
    // リストを表示メソッド
    getList () {
      let list = []
      let newObjects = {}

      axios.get('http://localhost:8081/api/user')
        .then(res => {
          list = res.data

          for (let i = 0; i < list.length; i++) {
            newObjects[i] = list[i]
          }
          console.log(newObjects)
          this.Obj = newObjects
        })
        .catch(error => {
          this.$message({
            message: '获取页面内容失败！',
            type: 'error',
            duration: 2000
          })
          console.log('获取排行出错！')
          console.error(error)
        })
    }
  },

  created () {
    this.getList()
  }

}
</script>
