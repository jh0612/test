<template>
  <div class="PaiHang">
    <InputText @listRef="created" />

    <!-- 表格整体结构放在父组件，表头只渲染一次 -->
    <el-table :data="pagedUsers" style="width: 100%">
      <el-table-column prop="id" label="ID" width="180"></el-table-column>
      <el-table-column prop="age" label="年齡" width="180"></el-table-column>
      <el-table-column prop="name" label="姓名"></el-table-column>
      <!-- 点赞数可以不显示所以注释掉 -->
      <el-table-column prop="liked" label="点赞数" width="120"></el-table-column>
      <el-table-column fixed="right" label="操作">
        <!-- 循环渲染子组件，每个子组件只负责一行的操作逻辑 -->
        <template slot-scope="scope">
          <UserList
            :user="scope.row"
            @update-user="handleUpdateUser"
            @delete-user="handleDeleteUser"
          />
        </template>
      </el-table-column>
    </el-table>

    <!-- 分页组件 -->
    <div class="block mt-4">
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page.sync="currentPage"
        :page-size="pageSize"
        layout="total, prev, pager, next"
        :total="totalCount">
      </el-pagination>
    </div>
  </div>
</template>

<script>
import UserList from '@/components/UserList.vue'
import InputText from '@/components/InputText.vue'
import axios from 'axios'

export default {
  name: 'LikesSortedView',
  components: {
    UserList,
    InputText
  },
  data () {
    return {
      users: [],
      currentPage: 1,
      pageSize: 10,
      totalCount: 0
    }
  },
  computed: {
    pagedUsers () {
      const startIndex = (this.currentPage - 1) * this.pageSize
      return this.users.slice(startIndex, startIndex + this.pageSize)
    }
  },
  methods: {
    getList () {
      axios.get('http://localhost:8081/api/user')
        .then(res => {
          this.users = res.data
          this.totalCount = res.data.length
        })
        .catch(error => {
          this.$message.error('获取数据失败！')
          console.error(error)
        })
    },
    handleSizeChange (val) {
      this.pageSize = val
      this.currentPage = 1
    },
    handleCurrentChange (val) {
      this.currentPage = val
    },
    handleUpdateUser (updatedUser) {
      const index = this.users.findIndex(u => u.id === updatedUser.id)
      if (index !== -1) this.users.splice(index, 1, updatedUser)
    },
    handleDeleteUser (userId) {
      this.users = this.users.filter(u => u.id !== userId)
      this.totalCount = this.users.length
    }
  },
  created () {
    this.getList()
  }
}
</script>
