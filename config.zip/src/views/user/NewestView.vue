<!-- src/views/NewestView.vue -->
<template>
  <div class="newest-view">
    <h1>按新加排序的内容</h1>
  </div>
</template>

<script>
export default {
  name: 'NewestView'
}
</script>
