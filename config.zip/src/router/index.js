import Vue from 'vue'
import VueRouter from 'vue-router'
import RandomView from '@/views/user/RandomView.vue' // 主布局页面（RandomView.vue文件格纳位置以及文件名日后统一到MainLayout）

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: '排行',
    component: () => import('../views/user/LikesSortedView.vue')
  },
  {
    path: '/Newest',
    name: '最新',
    // route level code-splitting
    // this generates a separate chunk (Newest.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/user/NewestView.vue')
  },
  {
    path: '/Random',
    name: 'RandomView',
    // component: () => import('../views/user/RandomView.vue')
    component: RandomView,
    // 路由参数：通过 query 传递当前要显示的组件标识
    // 例如：/home?view=dashboard 或 /home?view=user
    props: route => ({
      currentView: route.query.view || 'dashboard' // 默认显示 dashboard 组件
    })
  }
]

const router = new VueRouter({
  routes
})

export default router
