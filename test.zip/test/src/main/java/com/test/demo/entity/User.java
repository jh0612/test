/**
 * 
 */
package com.test.demo.entity;

import lombok.Data;

/**
 * @author 70998115
 *
 */


@Data
public class User {
	
	
	private String id;
	
	private String age;
	
	private String name;


}
