/**
 * 
 */
package com.test.demo.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.test.demo.entity.User;

/**
 * @author 70998115
 *
 */
@Repository
@Mapper
public interface UserMapper {
	
	//Select where
	User findUserById(String id);
	
	//insert
	int addUser(User user);
	
	//Select *
	List<User> getUserList();
	
	//Update by id
	void updateById(String id,String age,String name);
	
	//delete by id
	void deleteById(String id);
	
	

}
