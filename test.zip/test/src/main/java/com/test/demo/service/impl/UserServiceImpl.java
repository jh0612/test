/**
 * 
 */
package com.test.demo.service.impl;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.test.demo.entity.User;
import com.test.demo.mapper.UserMapper;
import com.test.demo.service.UserService;

/**
 * @author 70998115
 *
 */
@Service
public class UserServiceImpl implements UserService{
	
	@Autowired
	UserMapper userMapper;
	
	@Override
	public List<User> getUserLists() {
		List<User> list = userMapper.getUserList();
		List<User> collect = list.stream()
				.sorted((a, b) -> {
	                // 将字符串转换为整数后比较（年齡從小到大比較）
	                int idA = Integer.parseInt(a.getAge());
	                int idB = Integer.parseInt(b.getAge());
	                return Integer.compare(idA, idB);
	            })
//				.sorted(Comparator.comparing(User::getAge))
				.collect(Collectors.toList());
		collect.forEach(user -> System.out.println(user.toString()));
		System.out.println("********getUserLists********");
		return collect;

	}
	
	@Override
	public User findUserById(String id) {
		return userMapper.findUserById(id);
	}
	
	@Override
	public int addUser(User user) {
		
		return userMapper.addUser(user);

	}
	
	@Override
	public void updateById(String id,String age,String name) {
		userMapper.updateById(id, age, name);
	}
	
	@Override
	public void deleteById(String id) {
		userMapper.deleteById(id);
	}
	
	//用Stream流對取得的數據進行流式處理
	@Override
    public List<User> streamStu() {
    	System.out.println("********************StreamTest********************");
    	List<User> userList = userMapper.getUserList();
//    	long count = userList.stream().filter(user -> Integer.parseInt(user.getAge()) < 45).count();
    	List<User> collect = userList.stream().filter(user -> Integer.parseInt(user.getAge()) < 45).collect(Collectors.toList());
//    	return count;
        return collect;
    	
    }
}
