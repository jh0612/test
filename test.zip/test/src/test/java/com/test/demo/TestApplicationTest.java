package com.test.demo;

import javax.sql.DataSource;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * DBアクセステスト
 * @author 70998115
 *
 */
@SpringBootTest
public class TestApplicationTest {
	
	@Autowired
	DataSource data;
	
	@Test
	void contextLoads() throws Exception{
		System.out.println(data.getConnection().toString());
	}

}
