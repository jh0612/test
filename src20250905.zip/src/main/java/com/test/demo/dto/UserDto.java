/**
 * 
 */
package com.test.demo.dto;

import lombok.Data;

/**
 * @author 70998115
 * 用户账号信息，不带密码，用BeanUtils传递
 * BeanUtils.copyProperties(user, dto);
 */
@Data
public class UserDto {
	
	private Long id;
	
	private String username;
	
	private String phone;
	
	private String email;
	
	private Byte status;

}
