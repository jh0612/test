/**
 * 
 */
package com.test.demo.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.test.demo.entity.User;
import com.test.demo.exception.EntityNotFoundException;
import com.test.demo.mapper.UserMapper;
import com.test.demo.service.UserService;

/**
 * @author 70998115
 *
 */
@Service
public class UserServiceImpl implements UserService{
	
	@Autowired
	UserMapper userMapper;
	
	@Override
	public List<User> getUserLists() {
		List<User> list = userMapper.getUserList();
		List<User> collect = list.stream()
				.sorted((a, b) -> {
	                // 将字符串转换为整数后比较（年齡從小到大比較）
	                Long idA = a.getId();
	                Long idB = b.getId();
	                return Long.compare(idA, idB);
	            })
//				.sorted(Comparator.comparing(User::getAge))
				.collect(Collectors.toList());
		collect.forEach(user -> System.out.println(user.toString()));
		System.out.println("********getUserLists********");
		return collect;

	}
	
	@Override
	public User findUserById(Long id) {
		return userMapper.findUserById(id);
	}
	
	@Override
	public int addUser(User user) {
		
		return userMapper.addUser(user);

	}
	
	@Override
	public void updateById(Long id) {
		userMapper.updateById(id);
	}
	
	@Override
	public void deleteById(Long id) {
		userMapper.deleteById(id);
	}
	
	/*
	 * 点赞功能，之后加端末MAC判断？或者账户判断
	 */
	@Override
    @Transactional
    public User increaseLikes(Long id) {
        // 检查用户是否存在（替代orElseThrow的功能）
        User user = userMapper.findUserById(id);
        if (user == null) {
            throw new EntityNotFoundException("用户不存在: " + id);
        }
        
        // 执行点赞数增加
        int affected = userMapper.increaseLikes(id);
        if (affected <= 0) {
            throw new RuntimeException("更新点赞数失败");
        }
        
        // MyBatis不需要flush，直接重新查询获取最新数据
        return userMapper.findUserById(id);
    }

	/*
	 * 点赞功能，之后加端末MAC判断？或者账户判断
	 */
    @Override
    @Transactional
    public User decreaseLikes(Long id) {
        // 检查用户是否存在
        User user = userMapper.findUserById(id);
        if (user == null) {
            throw new EntityNotFoundException("用户不存在: " + id);
        }
        
        // 执行点赞数减少
        int affected = userMapper.decreaseLikes(id);
        if (affected <= 0) {
            throw new RuntimeException("更新点赞数失败");
        }
        
        // 重新查询获取最新数据
        return userMapper.findUserById(id);
    }
	
	//用Stream流對取得的數據進行流式處理
	@Override
    public List<User> streamStu() {
    	System.out.println("********************StreamTest********************");
    	List<User> userList = userMapper.getUserList();
//    	long count = userList.stream().filter(user -> Integer.parseInt(user.getAge()) < 45).count();
    	List<User> collect = userList.stream().filter(user -> Integer.parseInt(user.getPhone()) < 100).collect(Collectors.toList());
//    	return count;
        return collect;
    	
    }
}
