package com.test.demo.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.test.demo.entity.User;
import com.test.demo.service.UserService;

import lombok.extern.slf4j.Slf4j;

/**
 * @author 70998115
 *
 */
@RestController
@RequestMapping("/api/user")
@CrossOrigin(origins = "http://localhost:8089") // 跨域资源共享（CORS）策略 允许前端域名 本地调试用
//@CrossOrigin(origins = "http://10.97.24.24:8080") //打包用
@Slf4j
public class UserController {

	private final UserService userService;
	
	public UserController(UserService userService) {
		this.userService = userService;
	}
	
	@GetMapping
	public ResponseEntity<List<User>> getAllUser(){
		List<User> userList = userService.getUserLists();
		return ResponseEntity.ok(userList);
	}
	
	@DeleteMapping("/delete/{id}")
	public void deleteById(@PathVariable Long id){
		userService.deleteById(id);
	}
	
	@RequestMapping("/addUser")
	public Integer addUser(@RequestBody User user) {
        if(userService.findUserById(user.getId()) != null)
            return 0;//返回給了前端console
        return userService.addUser(user);
	}
	
	@PatchMapping("/editUser/{id}")
	public void editUser(@PathVariable Long id, @RequestBody User user) {
		//更新前のUser情報を入手
		User findUserById = userService.findUserById(id);
//		//各項目に対して判断する
//		if(user.getAge() != findUserById.getAge()) {
//			findUserById.setAge(user.getAge());
//			log.info("年齢を更新した");
//		}
//		if(user.getName() != findUserById.getName()) {
//			findUserById.setName(user.getName());
//			log.info("名前を更新した");
//		}
        userService.updateById(findUserById.getId());
	}
	
	/**
     * 增加用户点赞数
     */
//    @PutMapping("/increaseLikesById/{id}")
//    public ResponseEntity<Map<String, Object>> increaseLikes(@PathVariable Long id) {
//        User user = userService.increaseLikes(id);
//        Map<String, Object> response = new HashMap<>();
//        response.put("liked", user.getLiked());
//        response.put("id", user.getId());
//        return ResponseEntity.ok(response);
//    }

    /**
     * 减少用户点赞数
     */
//    @PutMapping("/decreaseLikesById/{id}")
//    public ResponseEntity<Map<String, Object>> decreaseLikes(@PathVariable Long id) {
//        User user = userService.decreaseLikes(id);
//        Map<String, Object> response = new HashMap<>();
//        response.put("liked", user.getLiked());
//        response.put("id", user.getId());
//        return ResponseEntity.ok(response);
//    }
	
	
}
