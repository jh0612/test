/**
 * 
 */
package com.test.demo.common;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author 70998115
 *
 */
//响应类：尽量将所有接口的响应信息封装到此对象中，返回给前端
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ResponseCommon {

  private String error;
  private boolean success; //默认false
  private Object data;

  /**
   * 响应成功，返回对象中保存 ""错误信息 string error，响应成功标记 bool ，数据 data
   * @param data data
   * @return 返回一个对象 通用响应对象，将所有响应信息统一为此对象
   */
  public static ResponseCommon success(Object data) {
      return new ResponseCommon("", true, data); //构造函数 Lombok 创建
  }
	
	/**
	* 响应结果返回失败，不带参，携带错误信息
	*/
  public static ResponseCommon error(String error) {
      return error(error, error);
  }

	/**
	* 可以携带参数返回失败的响应结果 和 错误信息
	*/
  public static ResponseCommon error(String error, Object data) {
      return new ResponseCommon(error, false, data);
  }

}

