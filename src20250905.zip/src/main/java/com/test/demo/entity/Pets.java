/**
 * 
 */
package com.test.demo.entity;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author 70998115
 *
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class Pets extends BaseEntity{
	
	//反序列化
	private static final long serialVersionUID = 1L;
    
	/** 主键 */
	private Long petsId;
	
	/** 主人customerId */
	private Long petsCustomerId;
	
	/** pet名字 */
	private String petsName;
	
	/** pet年龄 */
	private String petsAge;
	
	/** pet性别 */
	private String petsSex;
	
	/** 绝育（0：没做过 1：做过） */
	private String petsNeutered;
	
	/** 疫苗情况（0针，1针，2针，3针,9不明） */
	private String petsVaccineSituation;
	
	/** 健康状况（0活泼，1正常，2要观察，3较差，4生病中） */
	private String petsHealthStatus;
	
	/** 寄养情况（0：寄养中；1：已接走） */
	private String petsFostercareStatus;
	
	/** 寄养开始日 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date petsFosterStartdate;
	
	/** 寄养结束日 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date petsFosterEnddate;

}
