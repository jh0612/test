/**
 * 
 */
package com.test.demo.entity;

import java.util.Date;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author 70998115
 *
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class Customer extends BaseEntity{
	
	//反序列化
	private static final long serialVersionUID = 1L;
    
	/** 唯一标识客户的主键 */
	private Long customerId;
	
	/** 用户表的用户名 */
	private String customerUsername;
	
	/** 客户姓名 */
	private String customerName;
	
	/** 客户性别：'M'男   'F'女    'N'未知 */
	private Gender customerGender;
	
	/** 客户年龄 */
	private byte customerAge;
	
	/** 客户手机号码 */
	private String customerPhone;
	
	/** 客户电子邮件 */
	private String customerEmail;
	
	/** 客户住址 */
	private String customerAddress;
	
	/** 客户头像 */
	private String customerImage;
	
	/** 客户职业 */
	private String customerOccupation;
	
	/** 客户注册时间 */
	private Date customerRegisterTime;

}
