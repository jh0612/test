/**
 * 
 */
package com.test.demo.entity;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author 70998115
 *
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class Product extends BaseEntity{
	
	//反序列化
	private static final long serialVersionUID = 1L;

	/** 商品ID */
	private Long productId;
	
	/** 商品编号 */
	private String productProductid;
	
	/** 商品名 */
	private String productName;
	
	/** 商品分类 */
	private String productType;
	
	/** 进货价 */
	private BigDecimal productCost;
	
	/** 售价 */
	private BigDecimal productPrice;
	
	/** 商品品牌 */
	private String productBrand;
	
	/** 库存 */
	private int productInventory;
	
	/** 保质期（19991231：无期限） */
	private String productShelflife;
	
	/** 商品描述 */
	private String productDescription;
	
	/** 商品图片 */
	private String productImage;
	
	/** 商品上架时间 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date productLaunchTime;
	
	/** 商品状态 */
	private String productStatus;
	
	/** 商品销量 */
	private int productSales;
	
	/** 商品评分 */
	private int productRating;
	
	/** 商品标签 */
	private String productTag;

}
