/**
 * 
 */
package com.test.demo.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author 70998115
 *
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class GoodsCategory extends BaseEntity{
	
	//反序列化
	private static final long serialVersionUID = 1L;

	/** 分类id */
	private int id;
	
	/** 上级分类id,若值为0，表示上级分类是根节点。 */
	private int parentId;
	
	/** 分类名称 */
	private String name;
	
	/** 排序：用于对同级分类进行排序，按照从小到大的顺序排列。 */
	private int sort;
	
	/** 是否显示：0表示不显示，1表示显示。 */
	private byte isShow;
	
}
