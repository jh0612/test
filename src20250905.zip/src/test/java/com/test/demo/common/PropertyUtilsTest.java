/**
 * 
 */
package com.test.demo.common;

import java.util.Date;

import org.junit.jupiter.api.Test;
import org.springframework.beans.BeanUtils;
import org.springframework.boot.test.context.SpringBootTest;

import lombok.extern.slf4j.Slf4j;
import com.test.demo.dto.UserDto;
import com.test.demo.entity.User;

/**
 * @author 70998115
 *
 */
@SpringBootTest
@Slf4j
public class PropertyUtilsTest {
	
	@Test
	public void test1() {
		// 创建源对象并赋值
	    User user = new User();
	    user.setId(1L);
	    user.setUsername("japen");
	    user.setPassword("123456");
	    user.setPhone("18210000000");
	    user.setEmail("123546@qq.com");
	    user.setStatus((byte) 1);
	    user.setCreateBy("Admin");
	    user.setCreateTime(new Date());
	    
	    log.info("User: {} {} {}",user,user.getCreateBy(),user.getCreateTime());

	    // 创建目标对象
	    UserDto dto = new UserDto();
	    
	    // 复制属性（会复制名称和类型都相同的属性,并且指定属性的属性不会复制）
//	    PropertyUtils.copyProperties(user, dto,"id","liked");
	    BeanUtils.copyProperties(user, dto);
	    log.info("UserDto: {}",dto);
	    // 此时dto的name和age会被赋值为user的对应值
	    System.out.println(dto.getUsername()); // 输出：Sam
	    System.out.println(dto.getPhone());  // 输出：26
	}
	

}
