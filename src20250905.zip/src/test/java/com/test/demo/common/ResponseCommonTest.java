/**
 * 
 */
package com.test.demo.common;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

import lombok.extern.slf4j.Slf4j;



/**
 * @author 70998115
 *
 */
@SpringBootTest
@Slf4j
public class ResponseCommonTest {
	
	@Test
	public ResponseCommon test() {
		// 测试参数
		String testStr = "测试数据！！";
		// 校验参数，返回错误结果和信息
		if(testStr==null||"".equals(testStr)){
			return ResponseCommon.error("错误信息");
		}
		// 返回dto的同时将参数传递给前端
		return ResponseCommon.success(testStr);
	}

}
