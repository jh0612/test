package com.test.demo.service;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.test.demo.entity.User;

import lombok.extern.slf4j.Slf4j;


@SpringBootTest
@Slf4j
public class UserServiceTest {
	
	@Autowired
	UserService userService;
	
	@Test
	public void getUserListsTest() {
		userService.getUserLists();
	}

	@Test
	public void findUserByIdTest() {
		
		User findUserById = userService.findUserById(2L);	
		log.info("IDは2のユーザー情報情報：{}", findUserById);
		
	}
	
	@Test
	public void addUserTest() {
		//Test Over
//		User user = new User("5","11","鈴木スズキ");
//		int addUser = userService.addUser(user);
//		System.out.println(addUser);
	}
	
	@Test
	public void updateByIdTest() {
//		Long id = 1L;
//		User userAfter = userService.findUserById(id);
//		System.out.println(userAfter.toString());
//		userAfter.setAge("79");
//		userAfter.setName("大宮");
//		System.out.println("*******************************");
//		userService.updateById(userAfter.getId(),userAfter.getAge(),userAfter.getName());

	}
	
	@Test
	public void deleteByIdTest() {
		Long id = 99L;
		userService.deleteById(id);
	}
	
	@Test
	public void streamTest() {
//		long streamStu = userService.streamStu();
//		System.out.println(streamStu);
		List<User> streamStu = userService.streamStu();
		streamStu.forEach(System.out::println);
		System.out.println("********************StreamTest********************");
	}
	
}
