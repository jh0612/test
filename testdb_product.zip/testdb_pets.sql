CREATE DATABASE  IF NOT EXISTS `testdb` /*!40100 DEFAULT CHARACTER SET utf8 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `testdb`;
-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: testdb
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `pets`
--

DROP TABLE IF EXISTS `pets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pets` (
  `pets_id` bigint(10) NOT NULL AUTO_INCREMENT COMMENT 'pets表主键',
  `pets_ownerid` bigint(9) NOT NULL COMMENT 'pet主人id 外键，关联表用',
  `pets_name` varchar(45) NOT NULL COMMENT 'pet名字',
  `pets_age` varchar(2) NOT NULL COMMENT '年龄',
  `pets_sex` varchar(1) NOT NULL COMMENT '性别',
  `pets_neutered` varchar(1) NOT NULL DEFAULT '0' COMMENT '绝育（0：没做过 1：做过）',
  `pets_vaccine_situation` varchar(1) NOT NULL DEFAULT '9' COMMENT '疫苗情况（0针，1针，2针，3针,9不明）',
  `pets_health_status` varchar(30) NOT NULL DEFAULT '1' COMMENT '健康状况（0活泼，1正常，2要观察，3较差，4生病中）',
  `pets_fostercare_status` varchar(1) NOT NULL DEFAULT '0' COMMENT '寄养中？（0：寄养中；1：已接走）',
  `pets_foster_startdate` datetime NOT NULL COMMENT '寄养开始日',
  `pets_foster_enddate` datetime DEFAULT NULL COMMENT '寄养结束日',
  `is_deleted` varchar(1) NOT NULL COMMENT '逻辑删除FLG',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间，更新记录时，需要更新它',
  `update_by` varchar(45) NOT NULL COMMENT '修改人',
  `creator` varchar(45) NOT NULL COMMENT '创建人',
  `memo` text COMMENT '备考',
  PRIMARY KEY (`pets_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pets`
--

LOCK TABLES `pets` WRITE;
/*!40000 ALTER TABLE `pets` DISABLE KEYS */;
INSERT INTO `pets` VALUES (1,2,'coco','3','1','2','3','1','2','2025-09-04 00:00:00','2025-09-05 00:00:00','0','2025-09-04 12:54:30','2025-09-04 15:13:00','admin','admin','\'\'');
/*!40000 ALTER TABLE `pets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-04 15:52:15
