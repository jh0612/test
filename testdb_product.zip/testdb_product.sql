CREATE DATABASE  IF NOT EXISTS `testdb` /*!40100 DEFAULT CHARACTER SET utf8 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `testdb`;
-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: testdb
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `product_id` bigint(10) NOT NULL AUTO_INCREMENT COMMENT '主键 自增',
  `product_productid` varchar(20) NOT NULL DEFAULT '' COMMENT '商品编号20为，不为空UQ的不可重复',
  `product_name` varchar(120) NOT NULL DEFAULT '' COMMENT '商品名',
  `product_type` char(3) NOT NULL DEFAULT '000' COMMENT '商品分类，通过3位str表示，会专门有一个类别表 默认0',
  `product_cost` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '进货价',
  `product_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '售价',
  `product_brand` char(3) NOT NULL DEFAULT '000' COMMENT '商品品牌',
  `product_inventory` int(11) NOT NULL DEFAULT '0' COMMENT '库存',
  `product_shelflife` char(8) NOT NULL DEFAULT '19991231' COMMENT '保质期（19991231：无期限） 默认无期限\n',
  `product_description` varchar(255) NOT NULL DEFAULT '' COMMENT '商品描述',
  `product_image` varchar(255) NOT NULL DEFAULT '' COMMENT '商品图片（存储url或路径）',
  `product_launch_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '商品上架时间',
  `product_status` char(2) NOT NULL DEFAULT '00' COMMENT '商品的状态，例如上架、下架、售罄等',
  `product_sales` int(11) NOT NULL DEFAULT '0' COMMENT '商品销量',
  `product_rating` int(11) NOT NULL DEFAULT '100' COMMENT '商品评分',
  `product_tag` varchar(45) NOT NULL DEFAULT '000' COMMENT '商品标签 给商品打上标签，方便用户进行筛选和搜索',
  `is_deleted` varchar(1) NOT NULL COMMENT '逻辑删除FLG',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间，更新记录时，需要更新它',
  `update_by` varchar(45) NOT NULL COMMENT '修改人',
  `creator` varchar(45) NOT NULL COMMENT '创建人',
  `memo` text COMMENT '备考',
  PRIMARY KEY (`product_id`),
  UNIQUE KEY `product_productid_UNIQUE` (`product_productid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-04 15:52:16
